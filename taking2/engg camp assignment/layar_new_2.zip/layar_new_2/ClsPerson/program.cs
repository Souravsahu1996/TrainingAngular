﻿using System;

namespace ClsPerson
{
    public class Class1
    {
        public string name { get; set; }
        public int age { get; set; }
        public string placeofbirth { get; set; }
    }
}
