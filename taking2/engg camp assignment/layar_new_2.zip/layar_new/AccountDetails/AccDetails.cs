﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccountDetails
{
    public class AccDetails
    {
        public int Accno { get; set; }
        public string Acctype { get; set; }
        public int debit { get; set; }
        public int pin { get; set; }
        //string login { get; set; }
        //string password { get; set; }
        //double balance { get; set; }


    }
}
